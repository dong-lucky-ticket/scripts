// ==UserScript==
// @name         挂课-公需课
// @namespace    http://tampermonkey.net/
// @version      2024-07-18
// @description  try to take over the world!
// @author       You
// @match        https://m.mynj.cn:11188/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    console.log('"公需课"篡改猴注入成功')
    function log(str) {
        console.log(str)
    }
    // 检查播放器是否在播放
    function testVideoPlaying() {
        log('检查播放器是否在播放')
        const playerRef = document.querySelector('#example_video_html5_api')

        setTimeout(() => {
            if (playerRef.paused) {
                playerRef.play()
            } else {
                startNextSection()
            }
        }, 1000)
    }

    // 检测进度状态是否是已完成
    function testProgress() {
        const percent = document.querySelector('.learnpercent')
        log('检测进度状态是否是已完成 ' + new Date().toLocaleString() + '  ' + percent.innerText)
        if (percent.innerText.includes('已完成')) {
            startNextSection()
        } else {
            // 啥也不用干，继续循环
            loopTestProcess()
        }
    }

    // 开始下一段课时
    function startNextSection() {
        log('开始下一段课时')
        for (let element of document.querySelector('#content').children) {
            if (element.innerText.includes('未完成') || element.innerText.includes('未开始')) {
                element.children[1].click()
                return 0
            }
        }
        // 不被return掉就说明没有未完成了
        toCourseList()
    }

    // 前往课程列表
    function toCourseList() {
        log('前往课程列表')
        document.querySelector('.banner-2').children[1].click()
    }

    // 寻找可以开始学习的课程
    function findCanLearnCourse() {
        log('寻找可以开始学习的课程')

        const courseWrapper = document.querySelectorAll('.mycourse-row')
        const learnedCourse = JSON.parse(sessionStorage.getItem('learnedCourse') || '[]')

        for (let courseItem of courseWrapper) {
            if (courseItem.innerText.includes('未完成')) {
                let courseName = courseItem.querySelector('.mycourse-row-coursename').innerText
                if (!learnedCourse.includes(courseName)) {
                    learnedCourse.push(courseName)
                    sessionStorage.setItem('learnedCourse', JSON.stringify(learnedCourse))
                    courseItem.querySelector('.mycourse-row-operate').children[0].click()
                    return
                }
            }
        }

        // for (let element of courseListWrapper) {
        //   if (element.innerText.includes('开始学习')) {
        //     element.children[0].click()

        //     return
        //   }
        // }
    }

    // 自动播放第一个视频
    function playFirstSection() {
        log('自动播放第一个视频')
        const sectionList = document.querySelector('#content')
        for (let element of sectionList.children) {
            if (element.innerText.includes('点击学习')) {
                element.children[1].click()
                return
            }
        }
        toCourseList()
        log('没有需要播放的视频')
    }

    function loopTestProcess() {
        setTimeout(() => {
            testProgress()
        }, 3000)
    }

    function init() {
        const pathname = window.location.pathname
        if (pathname.includes('/player')) {
            // 是课程播放页面
            console.log('是课程播放页面')
            setTimeout(() => {
                testVideoPlaying()
                console.log('开始检测播放进度')
                loopTestProcess()
            }, 1000)

        } else if (pathname.includes('/courseDetail')) {
            // 课程详情页自动播放第一个视频
            console.log('是课程详情页面')
            setTimeout(() => {
                playFirstSection()
            }, 1500)
        } else if (pathname.includes('/myCourse')) {
            // 是课程列表页面
            console.log('是课程列表页面')
            setTimeout(() => {
                findCanLearnCourse()
            }, 1500)
        } else {
            // 其它情况。。。可能是搞错了
        }
    }
    init()
    // Your code here...
})();