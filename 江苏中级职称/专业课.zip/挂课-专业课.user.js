// ==UserScript==
// @name         挂课-专业课
// @namespace    http://tampermonkey.net/
// @version      2024-07-18
// @description  try to take over the world!
// @author       You
// @match        https://jxjy.mynj.cn:8283/*
// @icon         data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==
// @grant        none
// ==/UserScript==

(function() {
    'use strict';
    console.log('"专业课"篡改猴注入成功')
    function log(str) {
        console.log(str)
    }
    // 检查播放器是否在播放
    function testVideoPlaying() {
        log('检查播放器是否在播放')
        const playerRef = document.querySelector('#player-container-id_html5_api')
        setTimeout(() => {
            if (playerRef) {
                if (playerRef.paused) {
                    playerRef.muted = true
                    document.querySelector('.vjs-big-play-button').click()
                }

            } else {
                console.log('playerRef >>> ', playerRef)
                console.log('playerRef.paused >>> ', playerRef.paused)
                startNextSection()
            }
        }, 1000)
    }

    // 检测进度状态是否是已完成
    function testProgress() {
        const percent = document.querySelector('.learnpercent')
        const playerRef = document.querySelector('#player-container-id_html5_api')
        log('检测进度状态是否是已完成 ' + new Date().toLocaleString() + '  ' + percent.innerText + '  当前视频：' + (playerRef.paused ? '暂停' : '播放'))
        if (percent.innerText.includes('已完成')) {
            log(percent.innerText)

            startNextSection()
        } else {
            // 啥也不用干，继续循环
            loopTestProcess()
            if (playerRef && playerRef.paused) {
                log('烦死了，又偷偷暂停')
                playerRef.muted = true
                playerRef.play()
                log('重新开始')
            }
        }
    }

    // 开始下一段课时
    function startNextSection() {
        log('开始下一段课时')
        for (let element of document.querySelector('#content').children) {
            if (element.innerText.includes('未完成') || element.innerText.includes('未开始')) {
                element.children[1].click()
                return 0
            }
        }
        // 不被return掉就说明没有未完成了
        toCourseList()
    }

    // 前往课程列表
    function toCourseList() {
        log('前往课程列表')
        document.querySelector('.banner-2').children[2].click()
    }

    // 寻找可以开始学习的课程
    function findCanLearnCourse() {
        log('寻找可以开始学习的课程')

        const courseWrapper = document.querySelectorAll('.mycourse-row')
        const learnedCourse = JSON.parse(sessionStorage.getItem('learnedCourse') || '[]')

        for (let courseItem of courseWrapper) {
            if (courseItem.innerText.includes('未完成') || courseItem.innerText.includes('未开始')) {
                let courseName = courseItem.querySelector('.mycourse-row-coursename').innerText
                if (!learnedCourse.includes(courseName)) {
                    learnedCourse.push(courseName)
                    sessionStorage.setItem('learnedCourse', JSON.stringify(learnedCourse))
                    courseItem.querySelector('.mycourse-row-operate').children[0].click()
                    return
                }
            }
        }
    }

    // 自动播放第一个视频
    function playFirstSection() {
        log('自动播放第一个视频')
        const sectionList = document.querySelector('#content')
        for (let element of sectionList.children) {
            if (element.innerText.includes('点击学习')) {
                element.children[1].click()
                return
            }
        }
        toCourseList()
        log('没有需要播放的视频')
    }

    function loopTestProcess() {
        setTimeout(() => {
            testProgress()
        }, 3000)
    }

    function init() {
        const pathname = window.location.pathname
        if (pathname.includes('/player')) {
            // 是课程播放页面
            setTimeout(() => {
                console.log('是课程播放页面')
                testVideoPlaying()
                console.log('开始检测播放进度')
                loopTestProcess()
            }, 1000)
        } else if (pathname.includes('/courseDetail')) {
            // 课程详情页自动播放第一个视频
            setTimeout(() => {
                playFirstSection()
            }, 1500)
        } else if (pathname.includes('/myCourse')) {
            // 是课程列表页面
            setTimeout(() => {
                console.log('是课程列表页面')
                findCanLearnCourse()
            }, 1500)
        } else {
            // 其它情况。。。可能是搞错了
        }
    }

    init()
    // Your code here...
})();